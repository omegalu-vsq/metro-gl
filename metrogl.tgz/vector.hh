#pragma once

#include <cstdlib>
#include <iostream>
#include <vector>

#include <GL/glew.h>

namespace gl {
    class Vector3 {
        public:
            GLfloat x_;
            GLfloat y_;
            GLfloat z_;

            Vector3() = default;
            Vector3(GLfloat x, GLfloat y, GLfloat z);
            Vector3(const Vector3&) = default;
            ~Vector3() = default;

            friend Vector3 operator+(const Vector3 &lhs, const Vector3 &rhs);
            friend Vector3 operator-(const Vector3 &lhs, const Vector3 &rhs);
            friend GLfloat operator*(const Vector3 &lhs, const Vector3 &rhs);
            friend Vector3 operator*(const Vector3 &lhs, GLfloat scalar);
            friend Vector3 operator*(GLfloat scalar, const Vector3 &rhs);
            friend Vector3 operator/(const Vector3 &lhs, GLfloat scalar);
            friend Vector3 operator^(const Vector3 &lhs, const Vector3 &rhs);
            friend bool operator==(const Vector3 &lhs, const Vector3 &rhs);
            friend bool operator!=(const Vector3 &lhs, const Vector3 &rhs);
            Vector3 operator-() const;
            Vector3& operator=(const Vector3 &other);
            GLfloat& operator[](int i);

            void normalize();
            GLfloat norm();
            GLfloat* data(); 

            friend std::ostream& operator<<(std::ostream &out,Vector3 &vect);
    };

}
